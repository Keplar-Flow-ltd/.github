# The Keplar Flow Copy Law

House rules for web copy that reads like a person wrote it. Written for the site rebuild after the CEO flagged the old copy as obviously AI generated.

- Source of live copy: `/tmp/gh-pages/docs/index.html`
- Diagnosis of the live copy: abstract noun stacks, decorative triads (two in the manifesto paragraph alone), an em dash in the Decent Work memo, a "not X, it's Y" hero headline, and filler like "driving an agenda" and "sustainable economic opportunity".
- Conventions: fail examples below show em dashes as double hyphens (`--`) so this document itself contains zero of them. Every rewrite keeps the facts (practice names, contact details, URLs, program names) exactly as they are.

---

## Part 1: The 12 laws

| # | Law | The test | Fail | Fixed |
|---|-----|----------|------|-------|
| 1 | **No em dashes. Ever.** | Search the draft for the long dash character. Any hit, in any style, is a rejection. Periods, commas, colons, and parentheses do the same job. | "We build platforms -- and we stand behind them." | "We build platforms and we stand behind them." |
| 2 | **Concrete beats abstract.** | Point at it, count it, or photograph it. If you cannot, the noun is too abstract. | "We create sustainable economic opportunity." | "The knowledge stays on your payroll." |
| 3 | **One idea per sentence.** | Read the sentence, say it back from memory. If two ideas come back, split it. | "We combine automation efficiency with human judgment to deliver outcomes at scale." | "Automation carries the routine. A person signs off on what counts." |
| 4 | **Kill every "not just X but Y".** | Does the sentence define itself against a strawman? Any "not just", "not X, it's Y", or "instead of X, we Y" gets rewritten to state the claim straight. | "It's not just automation -- it's a partnership." | "We build the automation and stay on call." |
| 5 | **No decorative triads.** | Three parallel items: could you honestly delete one? Then delete it. A real list of three real things is fine; rhythm for rhythm's sake is not. | "at the edge, on the device, and in the moment" | "decisions that cannot wait for a server" |
| 6 | **Verbs before nouns.** | Circle the main verb. If it is "is", "drives", or "enables", or the action is hiding inside a noun like adoption or enablement, rebuild around a real action. | "Responsible technology adoption across teams and communities." | "Roll out new technology without steamrolling the team." |
| 7 | **Numbers and specifics, where honest.** | Any claim that could carry a number should. Where a number cannot be verified, name a concrete thing instead. Never invent a figure to sound specific. | "fast, seamless integration" | "a working checkout in a week" |
| 8 | **The Lagos table test.** | Read the line aloud. If you would not say it to a client sitting across a table in Lagos, cut it. | "We help institutions align on dignity and long-term resilience." | "We ask what fair work looks like, then build for it." |
| 9 | **Vary sentence length.** | Count words per sentence in a paragraph. If three sentences sit within two words of each other, rewrite one. Mix 4-word sentences with 20-word ones. | "We design resilient systems. We support inclusive teams. We deliver sustainable outcomes." | "We design systems that survive a bad day. Small teams run them. That is the point." |
| 10 | **No AI-tell vocabulary.** | Search the draft against the banned list below. Any hit is out, no appeals. | "Unlock seamless workflows and elevate your team." | "Take the busywork off your team." |
| 11 | **Active voice, named actor.** | Ask who does it. If the subject is "solutions", "systems", or "it", put a person or the company name in the subject slot. | "Decisions are empowered by intelligent systems." | "The system drafts the decision. Your person approves it." |
| 12 | **Headings are statements, not labels.** | Could someone disagree with the heading? A label cannot be wrong; a statement can. That is the point. | "Community" / "Our Solutions" | "What we give away" / "The machines should do the boring part" |

### The banned list (law 10, in full)

seamless, unlock, unleash, elevate, leverage, harness, empower, streamline, robust, game-changer, cutting-edge, state-of-the-art, future-proof, future-ready, pioneering, transformative, revolutionary, disrupt, supercharge, holistic, ecosystem (unless you literally mean one), landscape (the metaphor), navigate (the metaphor), journey, deep dive, dive in, delve, tapestry, foster, pivotal, "in today's fast-paced world", "at the intersection of", "reimagining X", "next level", "unlock the power of".

---

## Part 2: Receipts (what the research says)

1. **NN/g, Morkes and Nielsen, "Concise, SCANNABLE, and Objective"** (nngroup.com/articles/concise-scannable-and-objective-how-to-write-for-the-web): concise text improved measured usability by 58%, scannable layout 47%, objective language 27%. 79% of users scan a new page; only 16% read word by word. This is the evidence behind laws 2, 3, and 9.
2. **NN/g, "Plain Language Is for Everyone, Even Experts"** (nngroup.com/articles/plain-language-experts): plain language helps experts too, not just novices. Behind laws 2 and 8.
3. **The Atlantic, "The Biggest Tell That Something Was Written by AI"** (theatlantic.com/technology/2026/05/how-to-tell-ai-writing/687345): names "It's not just (X), it's (a greater Y)" as the single biggest AI tell. Behind law 4. The live hero headline is that construction.
4. **a16z, "Habits of AI Writing"** (a16zcrypto.com/posts/article/ai-writing-hallmarks-for-founders): catalogs "not just about X, it's about Y" where Y is fuzzier than X, and calls the em dash "now a canonical AI tell". Behind laws 1 and 4.
5. **Charlie Guo, "The Field Guide to AI Slop"** (ignorance.ai/p/the-field-guide-to-ai-slop, Oct 2025): AI detectors are unreliable and false-positive prone; clusters of tells (manufactured contrasts, rule-of-three lists, perfect parallelism, no specific detail) are the better heuristic. Behind laws 4, 5, and 7.
6. **The Economist, "How to spot AI writing"** (economist.com/culture/2026/07/30/how-to-spot-ai-writing): LLM prose is suspiciously clean, with fewer commas and no sentences starting with "But". Human rhythm is rougher. Behind law 9.
7. **Banned-word lists**: ContentBeta's 300+ list (contentbeta.com/blog/list-of-words-overused-by-ai), Ronak Ganatra's "We Can Smell the Prompt" (ronakganatra.com/posts/we-can-smell-the-prompt), and Vibe Working's AI slop list all converge on the same vocabulary. Behind law 10.
8. **37signals, Getting Real, "Copywriting is Interface Design"** (basecamp.com/gettingreal/09.7-copywriting-is-interface-design): "Great interfaces are written... every word matters." Their signal lines ("Work isn't war", "Err on the side of do") are law 12 in action: short, arguable statements.
9. **Linear** (linear.app): headline "The system for product development", a plain category declaration with no adjectives. **Stripe**: "Built for developers", plus docs kept deliberately neutral in voice (Strapi editorial handbook). Specifics like "seven lines of code" built the brand. Behind laws 7, 11, and 12.
10. **Nigerian fintech tone**: Paystack hires content writers with a "clear, conversational style" (profolio.ng listing) and positions itself as "a technology company solving payments problems for ambitious businesses"; a widely shared local take says "people trust people more than polished ads". Behind law 8: the market rewards direct, spoken-sounding copy.

---

## Part 3: Applied rewrites of the live sections

Every BEFORE is quoted verbatim from `/tmp/gh-pages/docs/index.html`. Facts are unchanged: only voice moves.

### 3.1 Hero (title + sub)

BEFORE:
> The future isn't smarter machines. It's smarter collaboration.
> Human-centered software for Industry 5.0. We automate the busywork so your people can do the work that matters.

Why it fails: the headline is the "not X, it's Y" construction with the stress moved; the sub leads with a jargon label ("Human-centered software for Industry 5.0") and ends on an abstraction ("the work that matters").

AFTER (paste-ready):
> **The machines should do the boring part.** *We build that software.*
>
> Keplar Flow is a software company in Abuja. We ship the system. Then we train the people who run it.

Notes: "Industry 5.0" stays in the title tag and moves fully into the manifesto; it no longer has to carry the hero. The service list already lives in the meta line and the marquee strip, so the sub does not repeat it. Buttons ("Start a conversation", "Book a meeting") and the meta line stay as they are.

### 3.2 The four practice cards

Card names and tags stay identical.

**01 Platform engineering**
BEFORE:
> Cloud platforms and software-as-a-service, built as an independent vendor to grow with your business instead of against it.

AFTER:
> We build cloud platforms and SaaS as an independent vendor. The platform grows with your business. And it stays yours.

("It stays yours" is the plain-language version of the lock-in claim.)

**02 Workflow automation**
BEFORE:
> Process automation and ERP integration, mapped to the way your teams actually work, not the way a manual says they should.

AFTER:
> We automate processes and integrate your ERP around the way your teams actually work. When the manual disagrees with reality, we follow reality.

(The best idea in the original, "actually work", survives. The "not the way" construction becomes its own sentence, which is how you would say it out loud.)

**03 Intelligent systems**
BEFORE:
> Agentic AI, IoT, and TinyML for decisions that need to happen at the edge, on the device, and in the moment.

AFTER:
> Agentic AI, IoT, and TinyML for decisions that cannot wait for a server. The device decides in the moment. A person can still overrule it.

(The prepositional triad "at the edge, on the device, and in the moment" collapses into one concrete image: no server to wait for. The human override is a brand truth, so it earns the third sentence.)

**04 Talent and learning**
BEFORE:
> Capacity building and EdTech programs, so your people own the systems we build and can stretch them further.

AFTER:
> We train the teams who will run what we build, through EdTech and hands-on programs. When we leave, they stretch the system without calling us. The knowledge stays on your payroll.

("Capacity building" survives once as a category because buyers search for it; the second sentence makes it concrete.)

### 3.3 Manifesto / ethos paragraph ("Human by design")

BEFORE:
> Keplar Flow is a human-centered technology company pioneering Industry 5.0. We combine the efficiency of automation with the things that make work worth doing: judgment, creativity, and trust. Instead of replacing human effort, we build intelligent systems that enhance collaboration, improve productivity, and create sustainable economic opportunity.

Why it fails: two triads in one paragraph, "pioneering" from the banned list, "combine X with Y" hedging, and a four-noun abstraction stack to finish. This is the most AI-looking paragraph on the site.

AFTER (paste-ready):
> Keplar Flow builds software for Industry 5.0. In that future, the machines do the repeating and the people do the judging. We like that split, so it is the shape of everything we ship: automation carries the routine, and a person signs off on what counts. Teams work faster when they trust their tools. People stay when the work respects them. Both show up in the numbers.

The three ticks under it, lightly retuned (the page currently says "by design" three times, which reads as a template):

- **Ethical by default.** A person makes the call. The system does what it is told.
- **Tested on bad days.** It keeps working when the plan falls apart.
- **Scaled with care.** We grow the system without grinding down the team that runs it.

### 3.4 Decent Work section

Section heading becomes a statement. Lead paragraph first.

BEFORE (heading + lead):
> A practical commitment to fair work
> Keplar Flow is driving a Decent Work agenda that helps founders, workers, and institutions align on dignity, productivity, equity, and long-term resilience in modern workplaces.

Why it fails: "driving an agenda" is nominalization on wheels, and the sentence stacks a triad of people onto a quad of abstractions. Nothing in it can be pictured.

AFTER (paste-ready):
> What fair work looks like in practice
> We run a Decent Work initiative at Keplar Flow. It asks one question: what does fair work look like now that software keeps doing more of it? We take the answers to founders and workers first, then to the institutions that set the rules. What comes out is practical: standards a company can start using this quarter.

The four numbered items:

| # | BEFORE | AFTER |
|---|--------|-------|
| 01 | Clear principles for dignified and inclusive work design. | Principles for dignified work, written in plain language. |
| 02 | Responsible technology adoption across teams and communities. | How to roll out new technology without steamrolling the team. |
| 03 | Actionable standards for fair opportunities and outcomes. | Standards for fair chances and fair outcomes. Ones you can check. |
| 04 | Practical pathways for organizations ready to implement now. | A starting path for organizations ready to begin this quarter. |

The memo aside. The live copy carries the only two literal em dashes on the site, both here.

BEFORE:
> Our working paper on the future of decent work asks what fair, dignified, productive work means for founders, teams, and institutions -- and how technology should serve it. We design every system we ship around that answer.
> Ask us about the Decent Work agenda -- hello@keplarflow.org.

AFTER (paste-ready; the "Our position" kicker and the H3 "Decent work is an engineering requirement" stay, that heading already passes law 12):
> We wrote a working paper on the future of decent work. It asks what fair, dignified work means for the founders who pay for it and the teams who do it. Every system we ship is designed around the answer.
>
> Ask us about it: hello@keplarflow.org.

### 3.5 Community section

BEFORE (heading + lead):
> Grow with the network
> Join a community of professionals and business owners building with us: open-source tools (Liluts, our little useful things), agentic AI ecosystems, and practical FinOps insights for scaling without the usual chaos.

Why it fails: "Join a community" is generic CTA-speak, "ecosystems" and "insights" are abstractions, and the offer is buried in a triad. The two genuinely charming facts, the name Liluts and "little useful things", deserve the front of the line.

AFTER (paste-ready):
> What we give away
> We open-source our small tools under the name Liluts, little useful things. Around them, a working community of builders and business owners trades notes on agentic AI and on FinOps. Scaling up is expensive. It does not have to be chaotic.

The two action cards:
- GitHub button text stays "Visit our GitHub" (it is an instruction, not copy), pointing at the same repo.
- Discord card: label "Community chat", value "Discord, coming soon". Optional warmer variant: "We are opening a Discord. It arrives soon." (replaces "project drops", which is hype-speak for code).

### 3.6 CTA banner (contact section)

BEFORE:
> Let's build the future of work.
> Tell us what slows your business down. We will show you what changes first.

Why it fails: only the heading does. "The future of work" is the most worn phrase in software marketing. The sub is the most human copy on the entire live site, concrete and sequenced, so it stays exactly as written.

AFTER (paste-ready):
> Bring us the bottleneck.
> Tell us what slows your business down. We will show you what changes first.

Buttons ("Book a meeting", "hello@keplarflow.org"), the phone number, and the address stay as they are.

### 3.7 Footer tagline

BEFORE:
> Tech Driven Innovation, Human by Design.

Why it fails: Title Case buzz-noun plus a comma splice; two abstractions and no verb.

AFTER (paste-ready):
> Software that works. People who pick up.

Alternate, if more local warmth is wanted: "Built in Abuja. Reachable by phone." Both are claims a reader can test, which is the point of a tagline.

---

## Part 4: Pre-flight check (run before any copy ships)

```bash
# Law 1: zero long dashes anywhere (em or en)
grep -nP '\x{2014}|\x{2013}' index.html

# Law 10: banned vocabulary, case-insensitive
grep -inE 'seamless|unlock|unleash|elevate|leverage|harness|empower|streamline|robust|game.?changer|cutting.?edge|state.of.the.art|future.?proof|pioneering|transformative|revolutionar|holistic|ecosystem|journey|deep.?dive|dive in|delve|tapestry|foster|pivotal|fast.paced|at the intersection|reimagin|supercharge|next level' index.html

# Law 4: strawman constructions
grep -inE "not just|isn'?t .+\. it'?s |instead of" index.html
```

Then the two tests no script can run: read every line aloud (law 8), and count sentence lengths down each paragraph (law 9). If a paragraph reads at one steady beat, break it somewhere honest.
