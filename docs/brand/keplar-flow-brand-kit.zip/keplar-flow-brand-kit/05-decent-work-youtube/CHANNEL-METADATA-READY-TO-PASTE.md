# Decent Work Center — Ready-to-Paste Channel Metadata

Every block below pastes directly into YouTube Studio → Customisation.
Copy blocks are the applet's approved presets (verbatim from `src/data.ts`).

---

## Basic Info tab

**Channel name**
```
Decent Work Center
```

**Handle** (already claimed)
```
@DecentWorkCenterKFL
```

**Channel description** (official ~154 words)
```
Industry 4.0 asked machines to be efficient. Industry 5.0 asks systems to be good to work with.

Decent Work Center explores what happens when modern technology finally centers the worker. Operated by Keplar Flow Limited, the channel translates the rise of agentic AI, open interoperability, and lean infrastructure into one practical question: what does good work look like in practice?

Our weekly videos focus on five core editorial pillars:
1. Easy Interoperability — Composing systems with open protocols rather than fragile custom glue.
2. Lean, Humane Infrastructure — FinOps and architectural simplicity as respect for people's time and budget.
3. Peak Systems–Human Relationship — Designing the collaborative "centaur" balance of trust, control, and worker agency.
4. Systems Culture — Documentation as care, handover as craft, and sustainable team rituals.
5. Little Useful Things — High-leverage habits, runbooks, and micro-tools that make daily work measurably kinder.

Rooted qualitatively in UN Sustainable Development Goal 8 (Decent Work & Economic Growth).
```

**40-word About blurb** (for channel cards / mobile previews / press)
```
Decent Work Center, operated by Keplar Flow Limited, champions human-centric and sustainable systems in the age of AI. Aligning qualitatively with UN Sustainable Development Goal 8, we explore interoperable tooling, lean infrastructure, and engineering practices that make modern work safe, productive, and dignified.
```

**Links**
```
Website: https://keplarflow.org
```
(Add social links only as those properties go live.)

**Contact email**
```
[CONFIRM BEFORE PUBLISHING — recommend a role account on keplarflow.org, e.g. a "decentwork" alias. Do not use a personal address; do not invent one.]
```

## Branding tab

| Studio field | File | Setting |
|---|---|---|
| Banner image | `01-youtube-studio-upload/DWC-Channel-Banner-2560x1440.png` | — (check crop preview on mobile/desktop/TV) |
| Picture | `01-youtube-studio-upload/DWC-Profile-Picture-800x800.png` | (alt available: `...-ALT-blue-on-light.png`) |
| Video watermark | `01-youtube-studio-upload/DWC-Video-Watermark-150x150-transparent.png` | Display: **Entire video** |

After upload: click **Publish**, then verify the live channel on one mobile and one desktop
browser (operator-attribution legibility in the mobile banner is a guardrail).

## Per-video publishing template

**Video description template** (fill bracketed slots)
```
[VIDEO TITLE]

In this video, we explore [1-2 sentences summarizing the central thesis].

Timestamps:
00:00 - Introduction & Context
01:30 - The Core Constraint
04:15 - Practical Walkthrough
07:20 - The Human Ergonomics Takeaway
08:45 - Key Runbook & Resources

Related Resources & Guides:
- Read our full runbook on this topic: [Link to verified repo or documentation]
- Subscribe to Decent Work Center for weekly systems breakdowns.

About Decent Work Center:
Decent Work Center is operated by Keplar Flow Limited. We examine the intersection of Industry 5.0 (human-centric, sustainable, and resilient systems) and the everyday practice of decent work. Rooted qualitatively in UN SDG 8 (Decent Work & Economic Growth).

Follow Keplar Flow Limited:
Website: keplarflow.org
Channel Handle: @DecentWorkCenterKFL
```

**AI-assistance disclosure footer** (append to every description; EU AI Act Art 50 /
YouTube altered-content discipline)
```
—
This video was produced with AI-assisted research, scripting, and/or visuals, with human
editorial judgment and final review by Keplar Flow Limited. Answer the "Altered content"
question truthfully in Studio for each upload; when visuals are synthetic or materially
AI-generated, state it here explicitly.
```

**Standing rules for descriptions** (from the applet guardrails): no client or partner
names; no internal metrics, traffic, or adoption numbers; no invented statistics — public
sources only or cut; always keep the operator attribution block.
