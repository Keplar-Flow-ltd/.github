# Decent Work Center — YouTube Channel Design Brief

**Client**: Keplar Flow Limited
**Channel**: Decent Work Center · https://www.youtube.com/@DecentWorkCenterKFL
**Package**: v1 Initial Assets (this folder)
**Prepared**: 21 September 2026
**Source of truth**: the Decent-Work-Center-yt applet (GitHub `AdebayoEmmanuel/Decent-Work-Center-yt`, deployed on Google AI Studio) — its `src/data.ts` defines the channel position, editorial pillars, taglines, copy presets, and asset specifications referenced throughout this brief.

---

## 1. What this package is

This folder contains a complete **v1 initial asset set**: upload-ready channel art at exact
YouTube Studio specifications, reusable video templates, safe-area verification guides, and
this brief. It is the **starting elevation** — a correct, on-brand, pixel-exact foundation
that the design team is engaged to **elevate to finished brand quality** (photography,
illustration, motion-ready compositions) without re-litigating dimensions, safe areas, or
spec compliance.

The team's prior work on Project GAIA set the standard this brief expects: clean systems
thinking married with polished visual execution.

## 2. Channel identity (fixed inputs — do not change without sign-off)

| Item | Value |
|---|---|
| Channel name | **Decent Work Center** |
| Handle | **@DecentWorkCenterKFL** |
| Operator attribution | "Operated by Keplar Flow Limited" — mandatory on banner, About, and public copy |
| Position | Industry 5.0 (human-centric, sustainable, resilient) × the everyday practice of decent work |
| Voice | Calm, precise, warm without fluff; practitioner-credible; "better Tuesday," never "revolution" |
| North star | SDG 8 (Decent Work) — qualitative alignment only, sourceable to UN goal text |

**Three approved banner taglines** (all under 8 words; v1 ships Option 1):
1. "Human-Centric Systems for Decent Work."
2. "Where Systems Serve the Worker's Rhythm."
3. "Agentic Technology. Human Judgment. Decent Work."

## 3. Brand tokens

**Core palette** (reconstructed from the K-mark SVG and the applet's palette; the
authoritative printed palette is `Keplar flow Branding.pdf` in the base zip — reconcile on
first open and flag any mismatch):

| Token | Hex | Use |
|---|---|---|
| K Blue (primary) | `#194AFF` | K mark, accents, operator line |
| K Blue soft | `#7C95FF` | small K-blue text on navy (lifts contrast) |
| Deep Navy canvas | `#0F172A` | banner/avatar/thumbnail base; gradient stops `#16213A → #0C1424` |
| Off-white | `#F8FAFC` | wordmark, headlines |
| Slate 300 / 400 | `#CBD5E1` / `#94A3B8` | secondary text |
| Warm gray (mid) | `#64748B` | tertiary text, hairlines |

**Pillar spectrum** (the five editorial pillars — used as the 5-segment bar and as
per-episode accent colors):

| Pillar | Hex |
|---|---|
| 1. Easy Interoperability | `#2563EB` |
| 2. Lean, Humane Infrastructure | `#0D9488` |
| 3. Peak Systems–Human Relationship | `#D97706` |
| 4. Systems Culture | `#9333EA` |
| 5. Little Useful Things | `#334155` |

Small kicker text in a pillar color on navy should be **lifted 25% toward white**
(e.g. `#2563EB → #5477F2`) — established during v1 QA for legibility.

**Typography** (both families ship in `keplar-flow-branding-assets.zip → 03 Fonts`):

| Role | Face | Notes |
|---|---|---|
| Headlines / wordmark | **Montserrat ExtraBold** | tracked +8% for the wordmark |
| Kickers / labels | Montserrat SemiBold | caps, tracked |
| Body / meta | Montserrat Medium / Regular | |
| Display accent | **Fixel** (regular only) | pixel-style display face — use LARGE only; its grid is illegible below ~60 px (v1 QA finding). Do not set taglines or small text in Fixel. |

**K mark**: use only the approved "Option One — K mark" masters (SVG + @4x PNGs in the
base zip; raster masters also copied to `05-base-brand-reference/`). Never redraw or
substitute.

## 4. Deliverable specifications (hard requirements)

| Asset | Exact size | Format | Max size | Notes |
|---|---|---|---|---|
| Channel banner | **2560 × 1440** | PNG/JPG | 6 MB | All-device safe area **1235 × 338 centered** (stricter than the common 1546 × 423 figure — this channel designs to the applet's spec) |
| Profile picture | **800 × 800** | PNG | 4 MB | Circular crop at render (98 px visible); ≥24 px padding inside the circle |
| Video watermark | **150 × 150** | PNG, transparent | 1 MB | White K at **75% opacity** (alpha ≤ 191); Studio setting: **"Entire video"** |
| Thumbnail template | **1280 × 720** | PNG | — | Keep 120 px clear at bottom-right (duration badge) |
| End screen | **1920 × 1080** | PNG | — | Elements above bottom 20%; subscribe circle clear of right 12% |
| Shorts template | **1080 × 1920** | PNG | — | Keep-outs: top ~220 px, right rail ~140 px, bottom ~420 px |

## 5. What v1 establishes (design rationale)

- **Centered safe-band stack**: pillar bar → K mark → wordmark → tagline → operator line,
  with 25–45 px gaps (verified by pixel-profile QA; see `04-safe-area-guides/`).
- **Pillar spectrum bar**: the channel's five pillars as a constant, quiet signature.
- **Systems constellation motif**: connected nodes bleeding off the banner's outer fields —
  interoperable systems made visible; fully croppable decoration.
- **Ghost K**: 6.5%-opacity oversized K in the right field, depth without noise.
- **Avatar system**: primary = white K on navy with K-blue ring; alt = blue K on off-white.
  Both survive the 98 px circle.
- **Templates** carry the episode kicker (pillar color), 3-line title zone (740 px column),
  meta line, channel lockup, and a 5-dot pillar rail panel.

**Two documented deviations from the applet's advisory notes** (both open to team review):
1. Operator line is **centered** in the safe band's foot rather than bottom-right — a
   symmetric stack reads cleaner at mobile banner height; the mandatory content and its
   in-safe-area legibility are unchanged.
2. Fixel is **excluded from small sizes** (see typography table).

## 6. The engagement — what the design team delivers

1. **Banner elevation.** Rebuild the banner composition at final quality using the
   applet's intended direction: authentic hi-res engineering/practitioner photography with
   a low-saturation slate overlay for text legibility (base photos per `keplar-flow-branding-assets`
   → event/studio photography, or equivalent licensed/shot material). All safe-area rules
   above are non-negotiable.
2. **Episode thumbnail set — Batch 1 (10 thumbnails).** One per curriculum episode; the
   applet prescribes a thumbnail concept for each (see §8 list). Deliver as a reusable
   Figma system (kicker / title zone / pillar accent / lockup slots), not one-off files.
3. **Avatar refinement.** Polish the primary (white K on navy). Optional exploration: a
   "DWC" monogram treatment — flagged only as exploration; the applet prescribes the K
   mark, so any switch requires explicit client sign-off.
4. **Watermark pass.** Confirm the 150 px transparent K reads at player scale; tune edge
   softness if needed (keep alpha ≤ 191, file < 1 MB).
5. **Template finalization.** Elevate the thumbnail / end-screen / Shorts templates in the
   same Figma system, keeping every keep-out zone marked in the GUIDES files.
6. **Editable sources.** Deliver Figma links + exported PNGs named per the convention in
   §7, mirroring this folder's structure.

## 7. Acceptance criteria (pass/fail per asset)

- Exact pixel dimensions and format per the §4 table; file under its size cap.
- Banner: wordmark, tagline, and operator attribution fully inside 1235 × 338; legible at
  mobile banner height (test at 1235 × 338 actual pixels).
- Avatar: survives circular crop with ≥24 px padding; legible at 98 px.
- Watermark: transparent PNG, alpha ≤ 191, centered mark, no clipped edges.
- Thumbnails: title readable at 320 px wide (feed scale); duration-badge corner clear.
- No client/partner names, no internal metrics, no invented statistics anywhere
  (see §9 guardrails).
- "Operated by Keplar Flow Limited" present on banner and in channel copy.
- File naming: `DWC-<Asset>-<WxH>[-variant].png` (matches this package).

## 8. Batch 1 thumbnail concepts (from the applet curriculum)

| # | Episode | Prescribed thumbnail concept | Pillar accent |
|---|---|---|---|
| 1 | What Is Industry 5.0, Actually? | Minimalist split frame: "Speed vs. Care", clean type on deep slate navy | `#2563EB` |
| 2 | From 4.0 to 5.0 | Diagram: "Fragile Optimization" → "Shock-Absorbing System" | `#2563EB` |
| 3 | Decent Work in the Age of Agentic AI | Human decision node governing parallel agent work streams | `#D97706` |
| 4 | Interoperability Is a Worker Benefit | Open standard socket vs. tangled proprietary wires | `#2563EB` |
| 5 | Lean Isn't Cheap — It's Kind | Bloated 40-box cloud diagram vs. clean 3-tier lean stack | `#0D9488` |
| 6 | The Human-in-the-Loop Checklist | Clipboard card, 5 checked circles, bold headline | `#334155` |
| 7 | Handover as Craft | Two hands passing a cleanly structured runbook | `#9333EA` |
| 8 | Designing for Recovery | Graceful degradation vs. catastrophic cliff collapse | `#0D9488` |
| 9 | The Centaur Team | Timeline: human decisions guiding automated pulses | `#D97706` |
| 10 | Little Useful Things #1 | Bold yellow & slate timer badge "5-Min Runbook" + markdown preview | `#334155` |

## 9. Redaction guardrails (apply to every asset and copy line)

From the applet — **strict**:
1. Always attribute operation: "operated by Keplar Flow Limited."
2. Zero client, partner, or engagement names — no hints.
3. Zero internal metrics, traffic, or adoption numbers (including community-site metrics).
4. No invented statistics, percentages, or indices; public sources only or cut.
5. Centaur framing: AI as collaborator; judgment, craft, and accountability stay human.
6. Editorial ban on hype verbs ("supercharge", "empower", "revolution").

## 10. Publishing disclosure discipline (compliance)

Channel content will be AI-assisted (scripts/copy via the AI Studio workflow). EU AI Act
Art 50 transparency obligations apply to Keplar-published content with EU reach, and
YouTube requires an altered-content answer per upload:
- Answer YouTube's **"Altered content"** question honestly on every upload.
- Keep the standing AI-assistance footer in video descriptions (template in
  `CHANNEL-METADATA-READY-TO-PASTE.md`).
- Synthetic or heavily AI-generated visuals get explicit disclosure in the description.
These rules bind published *content*; channel art itself carries no disclosure duty.

## 11. Handoff

- Deliverables: Figma file link + PNG exports, mirroring this folder's structure
  (`01-youtube-studio-upload/`, `02-video-templates/`), same naming convention.
- Flag on delivery: any palette deltas found against `Keplar flow Branding.pdf`, and any
  proposed deviation from §2 fixed inputs.
- Review: Emmanuel Adebayo (CEO, Keplar Flow Limited).

---

*Folder map, upload checklist, and ready-to-paste channel metadata live in this folder's
`README.md` and `CHANNEL-METADATA-READY-TO-PASTE.md`.*
